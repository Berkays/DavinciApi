module.exports = {
    "localmongoDB": "mongodb://localhost/DavinciDB",
    "remotemongoDB":"mongodb://admin:admin12345@ds161939.mlab.com:61939/davinci",
    "secret": "danvincisecretkey",
    "tokenExpireTime": "7 Days" //7 Days
}